/**
 * 云函数 aiFallback —— 唯一后端（契约 §5.5）
 *
 * 两件事：
 *   1. action='secCheck'  调微信内容安全接口 security.msgSecCheck
 *   2. action='chat'     大模型兜底通道（Agent / 直连失败时接手）
 *
 * 入参：
 *   { action: 'secCheck', content: string, scene: 2 }
 *   { action: 'chat', messages: [{role, content}], temperature: number, expectJson: boolean }
 *
 * 出参：
 *   { code: 0, data: any }
 *   { code: 1001, msg: '内容不合规' }
 *   { code: 1002, msg: '上游超时' }
 *   { code: 1003, msg: '上游错误', detail: string }
 *   { code: 1004, msg: '额度耗尽' }
 *   { code: 1005, msg: '参数错误' }
 *
 * 🔴 Key 只放云函数环境变量（控制台 → 云函数 → 配置）：
 *   LLM_BASE_URL  默认 https://api.deepseek.com/v1
 *   LLM_API_KEY   必填
 *   LLM_MODEL     默认 deepseek-flash
 *   前端与仓库里不得出现任何 API Key。
 */

const cloud = require('wx-server-sdk');
const https = require('https');

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });

// 云函数平台默认超时 20s，内部留 2s 余量，先于平台超时返回可读错误
const TIMEOUT_MS = 18000;

function ok(data) {
  return { code: 0, data };
}

function fail(code, msg, detail) {
  return { code, msg, detail: detail ? String(detail).slice(0, 300) : undefined };
}

/* ------------------------------ 内容安全 ------------------------------ */

async function secCheck(event, context) {
  const content = String(event.content || '').slice(0, 500);
  if (!content) return ok({ pass: true, empty: true });

  try {
    const res = await cloud.openapi.security.msgSecCheck({
      openid: (context && context.OPENID) || '',
      scene: Number(event.scene) || 2,
      version: 2,
      content
    });
    const suggest = res && res.result && res.result.suggest;
    if (suggest === 'risky') return fail(1001, '内容不合规');
    return ok({ pass: true, suggest: suggest || 'pass', label: (res && res.result && res.result.label) || 100 });
  } catch (e) {
    const errCode = e && (e.errCode || e.code);
    const errMsg = String((e && (e.errMsg || e.message)) || '');
    if (errCode === 87014 || /87014/.test(errMsg)) return fail(1001, '内容不合规');
    // 安全检查本身不可用时不能阻断主流程（否则漏网风险变成不可用风险）
    console.warn('[aiFallback] msgSecCheck unavailable:', errCode, errMsg);
    return ok({ pass: true, degraded: true });
  }
}

/* ------------------------------ 大模型兜底 ------------------------------ */

function postJson(urlStr, headers, body) {
  return new Promise((resolve, reject) => {
    const url = new URL(urlStr);
    const payload = JSON.stringify(body);
    const req = https.request(
      {
        hostname: url.hostname,
        port: url.port || 443,
        path: url.pathname + url.search,
        method: 'POST',
        headers: Object.assign(
          {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(payload)
          },
          headers
        )
      },
      (res) => {
        let raw = '';
        res.on('data', (chunk) => {
          raw += chunk;
        });
        res.on('end', () => resolve({ status: res.statusCode, body: raw }));
      }
    );
    req.on('error', reject);
    req.setTimeout(TIMEOUT_MS, () => {
      const err = new Error('UPSTREAM_TIMEOUT');
      err.code = 'UPSTREAM_TIMEOUT';
      req.destroy(err);
    });
    req.write(payload);
    req.end();
  });
}

async function chat(event) {
  const key = process.env.LLM_API_KEY;
  if (!key) {
    return fail(1003, '上游错误', 'LLM_API_KEY 未配置：请在云函数环境变量里设置');
  }

  const messages = Array.isArray(event.messages) ? event.messages : [];
  if (!messages.length) return fail(1005, '参数错误', 'messages 不能为空');
  if (messages.length > 12) return fail(1005, '参数错误', 'messages 最多 12 条');

  const baseUrl = (process.env.LLM_BASE_URL || 'https://api.deepseek.com/v1').replace(/\/+$/, '');
  const model = process.env.LLM_MODEL || 'deepseek-flash';
  const body = {
    model,
    messages: messages.map((m) => ({
      role: m && m.role ? String(m.role) : 'user',
      content: String((m && m.content) || '')
    })),
    temperature: typeof event.temperature === 'number' ? event.temperature : 0.3,
    stream: false
  };

  let res;
  try {
    res = await postJson(
      baseUrl + '/chat/completions',
      { Authorization: 'Bearer ' + key },
      body
    );
  } catch (e) {
    if (e && (e.code === 'UPSTREAM_TIMEOUT' || /timeout/i.test(String(e.message || ''))) ) {
      return fail(1002, '上游超时');
    }
    return fail(1003, '上游错误', (e && e.message) || '网络异常');
  }

  if (res.status === 429 || res.status === 402) return fail(1004, '额度耗尽', '上游返回 ' + res.status);
  if (res.status === 401 || res.status === 403) return fail(1003, '上游错误', '鉴权失败，检查 LLM_API_KEY');
  if (res.status >= 400) return fail(1003, '上游错误', 'HTTP ' + res.status + ' ' + res.body);

  let data;
  try {
    data = JSON.parse(res.body);
  } catch (e) {
    return fail(1003, '上游错误', '上游返回不是 JSON');
  }
  const text = data && data.choices && data.choices[0] && data.choices[0].message
    ? data.choices[0].message.content
    : '';
  if (!text) return fail(1003, '上游错误', '上游返回内容为空');
  return ok(text);
}

/* ------------------------------ 入口 ------------------------------ */

exports.main = async (event, context) => {
  const e = event || {};
  switch (e.action) {
    case 'secCheck':
      return secCheck(e, context);
    case 'chat':
      return chat(e);
    default:
      return fail(1005, '参数错误', '未知 action：' + e.action);
  }
};
